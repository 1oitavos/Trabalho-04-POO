import Control.ControleEsporte;
import Control.ControlePessoa;
import Control.ControleUsuario;
import Model.Esporte;
import Model.Participante;
import Model.PerfilUsuario;
import Model.Pessoa;

import java.util.Scanner;

public class Main {
    private static final Scanner ENTRADA = new Scanner(System.in);

    public static void main(String[] args) {
        ControlePessoa pessoas = new ControlePessoa();
        ControleEsporte esportes = new ControleEsporte();
        ControleUsuario usuarios = new ControleUsuario();

        cadastrarUsuariosIniciais(usuarios);

        int opcao;
        do {
            System.out.println("\n=== SISTEMA DE GESTAO ===\n1 - Login\n0 - Sair");
            opcao = lerInteiro("Opcao: ");

            switch (opcao) {
                case 1 -> login(pessoas, esportes, usuarios);
                case 0 -> System.out.println("Sistema encerrado.");
                default -> System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private static void login(ControlePessoa pessoas, ControleEsporte esportes, ControleUsuario usuarios) {
        System.out.println("\n=== LOGIN ===");
        Participante usuario = usuarios.autenticar(lerTexto("Usuario: "), lerTexto("Senha: "));

        if (usuario == null) {
            System.out.println("Login invalido. Solicite seu cadastro a um administrador.");
            return;
        }

        System.out.println("Login realizado com sucesso. Bem-vindo, " + usuario.getNome() + "!");
        if (usuario.getPerfil() == PerfilUsuario.ADMINISTRADOR) {
            menuAdministrador(pessoas, esportes, usuarios);
        } else {
            menuUsuario(usuario.getPerfil());
        }
    }

    private static void menuAdministrador(ControlePessoa pessoas, ControleEsporte esportes, ControleUsuario usuarios) {
        int opcao;
        do {
            System.out.println("\n=== MODULO ADMINISTRADOR ===\n1 - Gerenciar pessoas\n2 - Gerenciar esportes\n3 - Gerenciar participantes\n0 - Logout");
            opcao = lerInteiro("Opcao: ");

            switch (opcao) {
                case 1 -> menuPessoas(pessoas);
                case 2 -> menuEsportes(esportes);
                case 3 -> menuUsuarios(usuarios);
                case 0 -> System.out.println("Logout realizado.");
                default -> System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private static void menuUsuario(PerfilUsuario perfil) {
        int opcao;
        do {
            System.out.println("\n=== MODULO " + perfil + " ===\n0 - Sair");
            opcao = lerInteiro("Opcao: ");

            if (opcao != 0) {
                System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);

        System.out.println("Logout realizado.");
    }

    private static void menuPessoas(ControlePessoa pessoas) {
        int opcao;
        do {
            System.out.println("\n--- CRUD PESSOAS ---\n1 - Cadastrar | 2 - Consultar | 3 - Alterar | 4 - Excluir | 5 - Listar | 0 - Voltar");
            opcao = lerInteiro("Opcao: ");

            switch (opcao) {
                case 1 -> cadastrarPessoa(pessoas);
                case 2 -> exibir(pessoas.consultar(lerInteiro("ID: ")), "Pessoa");
                case 3 -> alterarPessoa(pessoas);
                case 4 -> exibirResultado(pessoas.excluir(lerInteiro("ID: ")));
                case 5 -> pessoas.listar();
                case 0 -> { }
                default -> System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private static void menuEsportes(ControleEsporte esportes) {
        int opcao;
        do {
            System.out.println("\n--- CRUD ESPORTES ---\n1 - Cadastrar | 2 - Consultar | 3 - Alterar | 4 - Excluir | 5 - Listar | 0 - Voltar");
            opcao = lerInteiro("Opcao: ");

            switch (opcao) {
                case 1 -> esportes.cadastrar(lerTexto("Nome: "), lerTexto("Descricao: "));
                case 2 -> exibir(esportes.consultar(lerInteiro("ID: ")), "Esporte");
                case 3 -> alterarEsporte(esportes);
                case 4 -> exibirResultado(esportes.excluir(lerInteiro("ID: ")));
                case 5 -> esportes.listar();
                case 0 -> { }
                default -> System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private static void menuUsuarios(ControleUsuario usuarios) {
        int opcao;
        do {
            System.out.println("\n--- CRUD PARTICIPANTES ---\n1 - Cadastrar | 2 - Consultar | 3 - Alterar | 4 - Excluir | 5 - Listar | 0 - Voltar");
            opcao = lerInteiro("Opcao: ");

            switch (opcao) {
                case 1 -> cadastrarParticipante(usuarios);
                case 2 -> exibir(usuarios.consultar(lerInteiro("ID: ")), "Participante");
                case 3 -> alterarParticipante(usuarios);
                case 4 -> exibirResultado(usuarios.excluir(lerInteiro("ID: ")));
                case 5 -> usuarios.listar();
                case 0 -> { }
                default -> System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private static void cadastrarPessoa(ControlePessoa pessoas) {
        pessoas.cadastrar(lerTexto("Nome: "), lerInteiro("Idade: "), lerTexto("Cidade: "), lerTexto("Bairro: "), lerTexto("Vinculo com o CEFET: "));
    }

    private static void alterarPessoa(ControlePessoa pessoas) {
        boolean alterado = pessoas.alterar(lerInteiro("ID: "), lerTexto("Nome: "), lerInteiro("Idade: "), lerTexto("Cidade: "), lerTexto("Bairro: "), lerTexto("Vinculo com o CEFET: "));
        exibirResultado(alterado);
    }

    private static void alterarEsporte(ControleEsporte esportes) {
        boolean alterado = esportes.alterar(lerInteiro("ID: "), lerTexto("Nome: "), lerTexto("Descricao: "));
        exibirResultado(alterado);
    }

    private static void cadastrarParticipante(ControleUsuario usuarios) {
        boolean cadastrado = usuarios.cadastrar(lerTexto("Nome: "), lerInteiro("Idade: "), lerTexto("Cidade: "), lerTexto("Bairro: "), lerTexto("Vinculo com o CEFET: "), lerTexto("Usuario: "), lerTexto("Senha: "), lerPerfil());
        System.out.println(cadastrado ? "Participante cadastrado com sucesso." : "Dados invalidos, usuario ja existente ou limite atingido.");
    }

    private static void alterarParticipante(ControleUsuario usuarios) {
        int id = lerInteiro("ID: ");
        boolean alterado = usuarios.alterar(id, lerTexto("Nome: "), lerInteiro("Idade: "), lerTexto("Cidade: "), lerTexto("Bairro: "), lerTexto("Vinculo com o CEFET: "), lerTexto("Usuario: "), lerTexto("Senha: "), lerPerfil());
        System.out.println(alterado ? "Participante alterado com sucesso." : "ID inexistente, dados invalidos ou usuario ja existente.");
    }

    private static PerfilUsuario lerPerfil() {
        while (true) {
            System.out.println("Perfil: 1 - Administrador | 2 - Organizador | 3 - Participante");
            int opcao = lerInteiro("Opcao: ");

            if (opcao == 1) return PerfilUsuario.ADMINISTRADOR;
            if (opcao == 2) return PerfilUsuario.ORGANIZADOR;
            if (opcao == 3) return PerfilUsuario.PARTICIPANTE;
            System.out.println("Opcao invalida.");
        }
    }

    private static void cadastrarUsuariosIniciais(ControleUsuario usuarios) {
        usuarios.cadastrar("Administrador", 30, "Timoteo", "Centro", "Servidor", "ADM", "123", PerfilUsuario.ADMINISTRADOR);
        usuarios.cadastrar("Ana Souza", 19, "Timoteo", "Centro", "Estudante", "ana", "123", PerfilUsuario.PARTICIPANTE);
        usuarios.cadastrar("Bruno Lima", 22, "Coronel Fabriciano", "Melo Viana", "Estudante", "bruno", "123", PerfilUsuario.PARTICIPANTE);
        usuarios.cadastrar("Carla Reis", 28, "Ipatinga", "Horto", "Professora", "carla", "123", PerfilUsuario.PARTICIPANTE);
        usuarios.cadastrar("Diego Alves", 35, "Timoteo", "Funcionarios", "Servidor", "diego", "123", PerfilUsuario.PARTICIPANTE);
        usuarios.cadastrar("Elisa Martins", 24, "Timoteo", "Alegre", "Visitante", "elisa", "123", PerfilUsuario.PARTICIPANTE);
    }

    private static void exibir(Object objeto, String tipo) {
        System.out.println(objeto == null ? tipo + " nao encontrado." : objeto);
    }

    private static void exibirResultado(boolean sucesso) {
        System.out.println(sucesso ? "Operacao realizada com sucesso." : "Registro nao encontrado.");
    }

    private static int lerInteiro(String mensagem) {
        while (true) {
            try {
                return Integer.parseInt(lerTexto(mensagem));
            } catch (NumberFormatException e) {
                System.out.println("Digite um numero inteiro valido.");
            }
        }
    }

    private static String lerTexto(String mensagem) {
        System.out.print(mensagem);
        return ENTRADA.nextLine().trim();
    }
}
