package Control;

import Model.Participante;
import Model.PerfilUsuario;

import java.util.ArrayList;

public class ControleUsuario {
    private final ArrayList<Participante> usuarios;
    private int proximoId;

    public ControleUsuario() { usuarios = new ArrayList<>(); proximoId = 1; }
    public boolean cadastrar(String nome, int idade, String cidade, String bairro, String vinculo, String nomeUsuario, String senha, PerfilUsuario perfil) {
        if (idade < 0 || nomeUsuarioEmUso(nomeUsuario, -1)) return false;
        usuarios.add(new Participante(proximoId++, nome, idade, cidade, bairro, vinculo, nomeUsuario, senha, perfil));
        return true;
    }
    public Participante consultar(int id) { for (Participante usuario : usuarios) if (usuario.getId() == id) return usuario; return null; }
    public Participante autenticar(String nomeUsuario, String senha) { for (Participante usuario : usuarios) if (usuario.getUsuario().equals(nomeUsuario) && usuario.getSenha().equals(senha)) return usuario; return null; }
    public boolean alterar(int id, String nome, int idade, String cidade, String bairro, String vinculo, String nomeUsuario, String senha, PerfilUsuario perfil) {
        Participante usuario = consultar(id);
        if (usuario == null || idade < 0 || nomeUsuarioEmUso(nomeUsuario, id)) return false;
        usuario.setNome(nome); usuario.setIdade(idade); usuario.setCidade(cidade); usuario.setBairro(bairro); usuario.setVinculoInstitucional(vinculo); usuario.setUsuario(nomeUsuario); usuario.setSenha(senha); usuario.setPerfil(perfil);
        return true;
    }
    public boolean excluir(int id) { Participante usuario = consultar(id); if (usuario == null) return false; usuarios.remove(usuario); return true; }
    public void listar() { if (usuarios.isEmpty()) { System.out.println("Nenhum participante cadastrado."); return; } for (Participante usuario : usuarios) System.out.println(usuario); }
    private boolean nomeUsuarioEmUso(String nomeUsuario, int idIgnorado) { for (Participante usuario : usuarios) if (usuario.getId() != idIgnorado && usuario.getUsuario().equals(nomeUsuario)) return true; return false; }
}
