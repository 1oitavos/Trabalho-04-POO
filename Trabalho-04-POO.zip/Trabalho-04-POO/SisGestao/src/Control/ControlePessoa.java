package Control;

import Model.Pessoa;

import java.util.ArrayList;

public class ControlePessoa {
    private final ArrayList<Pessoa> pessoas;
    private int proximoId;

    public ControlePessoa() {
        pessoas = new ArrayList<>();
        proximoId = 1;
    }

    public void cadastrar(String nome, int idade, String cidade, String bairro, String vinculo) {
        pessoas.add(new Pessoa(proximoId++, nome, idade, cidade, bairro, vinculo));
        System.out.println("Pessoa cadastrada com sucesso!");
    }

    public Pessoa consultar(int id) {
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getId() == id) return pessoa;
        }
        return null;
    }

    public boolean alterar(int id, String nome, int idade, String cidade, String bairro, String vinculo) {
        Pessoa pessoa = consultar(id);
        if (pessoa == null || idade < 0) return false;
        pessoa.setNome(nome); pessoa.setIdade(idade); pessoa.setCidade(cidade); pessoa.setBairro(bairro); pessoa.setVinculoInstitucional(vinculo);
        return true;
    }

    public boolean excluir(int id) {
        Pessoa pessoa = consultar(id);
        if (pessoa == null) return false;
        pessoas.remove(pessoa);
        return true;
    }

    public void listar() {
        if (pessoas.isEmpty()) { System.out.println("Nenhuma pessoa cadastrada."); return; }
        for (Pessoa pessoa : pessoas) System.out.println(pessoa);
    }
}
