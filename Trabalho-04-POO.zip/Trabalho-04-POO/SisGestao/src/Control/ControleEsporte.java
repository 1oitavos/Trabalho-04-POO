package Control;

import Model.Esporte;

import java.util.ArrayList;

public class ControleEsporte {
    private final ArrayList<Esporte> esportes;
    private int proximoId;

    public ControleEsporte() { esportes = new ArrayList<>(); proximoId = 1; }
    public void cadastrar(String nome, String descricao) { esportes.add(new Esporte(proximoId++, nome, descricao)); System.out.println("Esporte cadastrado com sucesso!"); }
    public Esporte consultar(int id) { for (Esporte esporte : esportes) if (esporte.getId() == id) return esporte; return null; }
    public boolean alterar(int id, String nome, String descricao) { Esporte esporte = consultar(id); if (esporte == null) return false; esporte.setNome(nome); esporte.setDescricao(descricao); return true; }
    public boolean excluir(int id) { Esporte esporte = consultar(id); if (esporte == null) return false; esportes.remove(esporte); return true; }
    public void listar() { if (esportes.isEmpty()) { System.out.println("Nenhum esporte cadastrado."); return; } for (Esporte esporte : esportes) System.out.println(esporte); }
}
