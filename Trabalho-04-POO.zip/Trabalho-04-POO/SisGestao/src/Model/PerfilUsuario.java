package Model;

public enum PerfilUsuario {
    ADMINISTRADOR,
    ORGANIZADOR,
    PARTICIPANTE
}
