package Model;

public class Pessoa {
    private final int id;
    private String nome;
    private int idade;
    private String cidade;
    private String bairro;
    private String vinculoInstitucional;

    public Pessoa(int id, String nome, int idade, String cidade, String bairro, String vinculoInstitucional) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.cidade = cidade;
        this.bairro = bairro;
        this.vinculoInstitucional = vinculoInstitucional;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getVinculoInstitucional() {
        return vinculoInstitucional;
    }

    public void setVinculoInstitucional(String vinculoInstitucional) {
        this.vinculoInstitucional = vinculoInstitucional;
    }

    @Override
    public String toString() {
        return "ID: " + id
                + " | Nome: " + nome
                + " | Idade: " + idade
                + " | Cidade: " + cidade
                + " | Bairro: " + bairro
                + " | Vinculo: " + vinculoInstitucional;
    }
}
