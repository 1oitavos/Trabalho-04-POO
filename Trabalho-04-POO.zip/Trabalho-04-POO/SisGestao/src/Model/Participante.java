package Model;

public class Participante extends Pessoa {
    private String usuario;
    private String senha;
    private PerfilUsuario perfil;

    public Participante(int id, String nome, int idade, String cidade, String bairro,
                        String vinculoInstitucional, String usuario, String senha,
                        PerfilUsuario perfil) {
        super(id, nome, idade, cidade, bairro, vinculoInstitucional);
        this.usuario = usuario;
        this.senha = senha;
        this.perfil = perfil;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public PerfilUsuario getPerfil() {
        return perfil;
    }

    public void setPerfil(PerfilUsuario perfil) {
        this.perfil = perfil;
    }

    @Override
    public String toString() {
        return super.toString()
                + " | Perfil: " + perfil
                + " | Usuario: " + usuario;
    }
}
